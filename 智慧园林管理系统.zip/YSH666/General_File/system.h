#ifndef __SYSTEM_H
#define __SYSTEM_H

void System_Init();
void System_Loop();

#endif
