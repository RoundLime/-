#include "debug.h"
#include "stdio.h"
#include "stdarg.h"
#include "Serial.h"
#include "system.h"

void USART3_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART1_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

u16 Usart3_Rc_Buff[20]={};
u8 Serial_TxPacket[2];
u8 Serial_RxPacket[2];
u8 Serial_RxFlag;
u8 Mode = 0;
//uint8_t RxData;
//uint8_t RxFlag;
/*
************************************************************
*   �������ƣ�   Usart1_Init
*
*   �������ܣ�   ����1��ʼ��
*
*   ��ڲ�����   baud���趨�Ĳ�����
*
*   ���ز�����   ��
*
*   ˵����     TX-PA9      RX-PA10
************************************************************
*/
void Usart1_Init(unsigned int baud)
{
    GPIO_InitTypeDef gpioInitStruct;
    USART_InitTypeDef usartInitStruct;
    NVIC_InitTypeDef nvicInitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    //PA9   TXD
    gpioInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    gpioInitStruct.GPIO_Pin = GPIO_Pin_9;
    gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpioInitStruct);

    //PA10  RXD
    gpioInitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    gpioInitStruct.GPIO_Pin = GPIO_Pin_10;
    gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpioInitStruct);

    usartInitStruct.USART_BaudRate = baud;
    usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;     //��Ӳ������
    usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                     //���պͷ���
    usartInitStruct.USART_Parity = USART_Parity_No;                                 //��У��
    usartInitStruct.USART_StopBits = USART_StopBits_1;                              //1λֹͣλ
    usartInitStruct.USART_WordLength = USART_WordLength_8b;                         //8λ����λ
    USART_Init(USART1, &usartInitStruct);

    USART_Cmd(USART1, ENABLE);                                                      //ʹ�ܴ���

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);                                  //ʹ�ܽ����ж�

    nvicInitStruct.NVIC_IRQChannel = USART1_IRQn;
    nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
    nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 0;
    nvicInitStruct.NVIC_IRQChannelSubPriority = 2;
    NVIC_Init(&nvicInitStruct);

}
void Usart2_Init(unsigned int baud)
{

    GPIO_InitTypeDef gpioInitStruct;
    USART_InitTypeDef usartInitStruct;
    NVIC_InitTypeDef nvicInitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    //PA2   TXD
    gpioInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    gpioInitStruct.GPIO_Pin = GPIO_Pin_2;
    gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpioInitStruct);

    //PA3   RXD
    gpioInitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    gpioInitStruct.GPIO_Pin = GPIO_Pin_3;
    gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpioInitStruct);

    usartInitStruct.USART_BaudRate = baud;
    usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;     //��Ӳ������
    usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;                     //���պͷ���
    usartInitStruct.USART_Parity = USART_Parity_No;                                 //��У��
    usartInitStruct.USART_StopBits = USART_StopBits_1;                              //1λֹͣλ
    usartInitStruct.USART_WordLength = USART_WordLength_8b;                         //8λ����λ
    USART_Init(USART2, &usartInitStruct);

    USART_Cmd(USART2, ENABLE);                                                      //ʹ�ܴ���

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);                                  //ʹ�ܽ����ж�

    nvicInitStruct.NVIC_IRQChannel = USART2_IRQn;
    nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
    nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 0;
    nvicInitStruct.NVIC_IRQChannelSubPriority = 0;
    NVIC_Init(&nvicInitStruct);

}
void Usart3_Init()
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;


    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3 , ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);

    //PB10    TXD
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    //PB11    RXD
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;

    USART_Init(USART3, &USART_InitStructure);
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART3, ENABLE);
}

void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len)
{

    unsigned short count = 0;

    for(; count < len; count++)
    {
        USART_SendData(USARTx, *str++);                                 //��������
        while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);     //�ȴ��������
    }

}
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...)
{
    unsigned char UsartPrintfBuf[296];
    va_list ap;
    unsigned char *pStr = UsartPrintfBuf;

    va_start(ap, fmt);
    vsnprintf((char *)UsartPrintfBuf, sizeof(UsartPrintfBuf), fmt, ap);                         //��ʽ��
    va_end(ap);

    while(*pStr != 0)
    {
        USART_SendData(USARTx, *pStr++);
        while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
    }
}

void Usart3_Send_arr( u_int16_t *data, u_int8_t len  )
{
  while(len)
  {

      USART_SendData(USART3, *data++);
      while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==0);
      len--;
  }
}
void Usart3_Send_datapack(uint8_t data)
{

      USART_SendData(USART3, data);
      while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==0);

}

void Usart3_Send_String(char *String)
{
      uint8_t i;
      for (i = 0; String[i] !='\0'; i++) {
          Usart3_Send_datapack(String[i]);

    }
}
uint32_t Usart3_Send_Pow(uint32_t x,uint32_t y)
{
      uint32_t Result = 1;
      while(y--){

          Result *= x;
      }
      return Result;
}


void Usart3_Send_Number(uint32_t Num,uint8_t Len)
{
      uint8_t i;
      for (i = 0; i < Len; i++) {
          Usart3_Send_datapack(Num / Usart3_Send_Pow(10,Len - i -1) % 10 + '0' );

    }
}

int fputc(int ch , FILE *f ){

    Usart3_Send_datapack(ch);
    return ch;

}
uint8_t USART3_GetRxFlag(void){

    if (Serial_RxFlag == 1) {
        Serial_RxFlag = 0;
        return 1;
    }
    return 0;
}


void USART3_IRQHandler(void)
{
    static uint8_t RxState = 0;
    static uint8_t pRxpacket = 0;


    if (USART_GetITStatus(USART3, USART_IT_RXNE)==SET) {

    uint8_t RxData = USART_ReceiveData(USART3);

    if (RxState == 0) {
        if (RxData == 0xEE) {
            RxState = 1;

        }
    }else if (RxState == 1) {

        Serial_RxPacket[pRxpacket] = RxData;
        pRxpacket++;
        if (pRxpacket >= 2) {
            pRxpacket = 0;
            RxState = 2;

        }
    }else if (RxState == 2) {
        if (RxData == 0xFE) {
            RxState = 0;
            Serial_RxFlag = 1;
        }
    }
    USART_ClearITPendingBit(USART3, USART_IT_RXNE);
    }
}
void USART1_IRQHandler(void)
{

    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) //�����ж�
    {
        USART_ClearFlag(USART1, USART_FLAG_RXNE);
    }

}

