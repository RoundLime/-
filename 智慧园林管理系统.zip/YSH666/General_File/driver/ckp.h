#ifndef __CKP_H
#define __CKP_H

void ckp_Init();
void Serial_Mode();
void RTC_SandTime();
void Send_cgq();
void GET_nuFlag();
void GET_Tfalg();
void get_RX();
#endif
