#ifndef __MOTOU_H
#define __MOTOU_H

void Motor_Init(void);
void Motor_SetSpeed(int8_t Speed);
#endif
