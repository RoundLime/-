#include "debug.h"
#include "ReadDHT11.h"
#include "dht11.h"

DHT11_Data_TypeDef DHT11_Data;

int Read_DHT11_humi()
{
    unsigned char humi1 = 0;
    DHT11_GPIO_Config();
    if (Read_DHT11(&DHT11_Data) == 1) {
           humi1 = DHT11_Data.humi_int;
     }
    return humi1;
}
int Read_DHT11_temp()
{
    unsigned char temp1 = 0;
    DHT11_GPIO_Config();
    if (Read_DHT11(&DHT11_Data) == 1) {
           temp1 = DHT11_Data.temp_int;
     }
    return temp1;
}
