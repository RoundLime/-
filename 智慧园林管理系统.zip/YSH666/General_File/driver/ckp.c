#include "debug.h"
#include "RTC.h"
#include "Serial.h"
#include "Uart.h"
#include "co2.h"
uint8_t MyArray1[] = {0x7E, 0x05, 0x41, 0x00 , 0x01, 0x45, 0xEF};//1-��
uint8_t MyArray2[] = {0x7E, 0x05, 0x41, 0x00 , 0x02, 0x46, 0xEF};//2-����
uint8_t MyArray3[] = {0x7E, 0x05, 0x41, 0x00 , 0x03, 0x47, 0xEF};//3-��ʾ��
uint8_t MyArray4[] = {0x7E, 0x05, 0x41, 0x00 , 0x04, 0x40, 0xEF};//4-��Ȫ
uint8_t MyArray5[] = {0x7E, 0x05, 0x41, 0x00 , 0x05, 0x41, 0xEF};//5
uint8_t MyArray6[] = {0x7E, 0x05, 0x41, 0x00 , 0x06, 0x42, 0xEF};//6
uint8_t MyArray7[] = {0x7E, 0x05, 0x41, 0x00 , 0x07, 0x43, 0xEF};//7
uint8_t MyArray8[] = {0x7E, 0x05, 0x41, 0x00 , 0x08, 0x4C, 0xEF};//8
uint8_t MyArray9[] = {0X7E, 0X05, 0X41, 0X00 , 0X09, 0X4D, 0XEF};//9
uint8_t MyArray10[] = {0X7E, 0X05, 0X41, 0X00 , 0X0A, 0X4E, 0XEF};//10
uint8_t MyArray11[] = {0X7E, 0X05, 0X41, 0X00 , 0X0B, 0X4F, 0XEF};//11
uint8_t MyArray12[] = {0X7E, 0X05, 0X41, 0X00 , 0X0C, 0X48, 0XEF};//12
uint8_t MyArray13[] = {0x7E, 0x05, 0x41, 0x00 , 0x0D, 0x49, 0xEF};//13
uint8_t MyArray14[] = {0x7E, 0x05, 0x41, 0x00 , 0x0E, 0x4A, 0xEF};//14
uint8_t MyArray15[] = {0x7E, 0x05, 0x41, 0x00 , 0x0F, 0x4B, 0xEF};//15-
uint8_t MyArray16[] = {0x7E, 0x05, 0x41, 0x00 , 0x10, 0x54, 0xEF};//16
uint8_t MyArray17[] = {0x7E, 0x05, 0x41, 0x00 , 0x11, 0x55, 0xEF};//17
uint8_t MyArray18[] = {0x7E, 0x05, 0x41, 0x00 , 0x12, 0x56, 0xEF};//18

u_int16_t Time[3] = {0};
u8 cFlag = 0;
//��ʼ����������������
void ckp_Init(){

    //NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
        Usart3_Init();
        //Serial_Init();
        uart4_init();
        co_Init();
        RTC_Init();
        RTC_Set(2024, 4, 23,00, 00, 00);
}


//��������ѡ��
void Serial_Mode(){

        if(USART3_GetRxFlag() == 1 && Serial_RxPacket[0] == 0xE3)
               {
                   switch(Serial_RxPacket[1]){

                                    case 0x01:
                                           {
                                               Serial_SendArray(MyArray1,7);
                                               //Usart3_Send_datapack(01);
                                           }
                                           break;
                                    case 0x02:
                                           {
                                               Serial_SendArray(MyArray2,7);
                                               //Usart3_Send_datapack(02);
                                           }
                                           break;
                                    case 0x03:
                                          {
                                              Serial_SendArray(MyArray3,7);

                                          }
                                          break;
                                    case 0x04:
                                          {
                                              Serial_SendArray(MyArray4,7);

                                           }
                                          break;
                                    case 0x05:
                                           {
                                              Serial_SendArray(MyArray5,7);

                                           }
                                          break;
                                    case 0x06:
                                           {
                                              Serial_SendArray(MyArray6,7);

                                           }
                                          break;
                                    case 0x07:
                                           {
                                              Serial_SendArray(MyArray7,7);

                                           }
                                          break;
                                    case 0x08:
                                           {
                                              Serial_SendArray(MyArray8,7);

                                           }
                                          break;
                                    case 0x09:
                                           {
                                              Serial_SendArray(MyArray9,7);

                                           }
                                          break;
                                    case 0x00:
                                          {
                                              Serial_SendArray(MyArray10,7);

                                          }
                                          break;
                              }
               }


}

//�ϴ�ʱ��
void RTC_SandTime(){

    Time[0] = calendar.hour;
    Usart3_Send_String("n0.val=");
    Usart3_Send_Number(Time[0],2);
    Usart3_Send_String("\xFF\xFF\xFF");
    Time[1] = calendar.min;
    Usart3_Send_String("n1.val=");
    Usart3_Send_Number(Time[1],2);
    Usart3_Send_String("\xFF\xFF\xFF");
    Time[2] = calendar.sec;
    Usart3_Send_String("n2.val=");
    Usart3_Send_Number(Time[2],2);
    Usart3_Send_String("\xFF\xFF\xFF");
    //Usart3_Send_arr(&Time, 3);
}

////��ȡ�ϴ����ݱ�־λ
//void GET_nuFlag(){
//        if(USART3_GetRxFlag() == 1 && Serial_RxPacket[0] == 0xE4){
//        switch(Serial_RxPacket[1]){
//
//        case 0x01:
//                  {
//                     cFlag = 1;
//                  }
//                  break;
//        case 0x00:
//                  {
//                      cFlag = 0;
//                  }
//                  break;
//
//        }
//    }
//
//}


//�ϴ�����������
void Send_cgq(){
    //GET_nuFlag();
    //if (cFlag == 1) {

         //�ϴ�co2����
        Usart3_Send_String("x2.val=");
        Usart3_Send_Number(get_co()*100,4);
        Usart3_Send_String("\xFF\xFF\xFF");

    //}

}

