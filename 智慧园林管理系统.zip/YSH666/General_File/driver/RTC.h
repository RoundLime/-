#ifndef __RTC_H
#define __RTC_H

#include "debug.h"

#define RTC_REFRESH_MASK        0x01
#define RTC_ALARM_MASK          0x02
#define RTC_DATE_REFRESH_MASK   0x04

typedef struct
{
    vu8 hour;
    vu8 min;
    vu8 sec;

    vu16 w_year;
    vu8  w_month;
    vu8  w_date;
    vu8  week;

    unsigned char flag;
} _calendar_obj;

typedef struct
{
    signed char  month;
    signed char  date;

    unsigned char is_leap_month;//[7]Ϊ��ǰ�Ƿ�Ϊ���£�[6:0]Ϊ����

    //����һ���ֽ����ڴ洢'\0'
    unsigned char zodiac[9];//�洢��ɵ�֧��Ф,���î����
    unsigned char sdata[9];//�洢ũ�����ڣ�������إ��
} _lunar_obj;

unsigned char RTC_Init(void);
unsigned char RTC_Is_Leap_Year(unsigned int year);
unsigned char RTC_Alarm_Set(unsigned int syear, unsigned char smon, unsigned char sday, unsigned char hour, unsigned char min, unsigned char sec);
unsigned char RTC_Set(unsigned int syear, unsigned char smon, unsigned char sday, unsigned char hour, unsigned char min, unsigned char sec);
unsigned char RTC_ToLunar(unsigned int year, unsigned char mon, unsigned char day);
unsigned char RTC_RST();

extern _calendar_obj calendar;
extern _lunar_obj lunar;

#endif
