#ifndef _READDHT11_H_
#define _READDHT11_H_

int Read_DHT11_humi();
int Read_DHT11_temp();



#endif
