#include "debug.h"
#include "ADC.h"

void co_Init(){

    ADC_Function_Init();

}
u_int16_t get_co(){

    u16 co = Get_Adc_Average(1,5) * 0.024;

    return co;

}
