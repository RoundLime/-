#ifndef __UART_H
#define __UART_H

extern u8 Serial_TxPacket[];
extern u8 Serial_RxPacket[];
extern u8 Mode;

#define USART_DEBUG     USART1

void Usart1_Init(unsigned int baud);
void Usart2_Init(unsigned int baud);
void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len);
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...);
void USART1_IRQHandler(void);


void Usart3_Init();

void Usart3_Send_datapack(uint8_t data);
void Usart3_Send_arr( u_int16_t *data, u_int8_t len  );
void Usart3_Send_String(char *String);
uint32_t Usart3_Send_Pow(uint32_t x,uint32_t y);
void Usart3_Send_Number(uint32_t Num,uint8_t Len);
uint8_t USART3_GetRxFlag(void);
uint8_t USART3_GetRxData(void);
void USART3_IRQHandler(void);
void Serial_Printf(char *format,...);
void Serial_SendPacket(u8 *Packet);
int fputc(int ch , FILE *f );

#endif
