
#ifndef __PQ_H
#define __PQ_H

void pq_Init();
void pq_Start();
u_int16_t GET_fbadc();
#endif


