#ifndef __LEDDZ_H
#define __LEDDZ_H

#define LEDDZ_PIN     GPIO_Pin_5
#define LEDDZ_PORT    GPIOE
#define LEDDZ_CLK     RCC_APB2Periph_GPIOE

#define LEDDZ_SET     GPIO_SetBits(LEDDZ_PORT, LEDDZ_PIN)
#define LEDDZ_RESET   GPIO_ResetBits(LEDDZ_PORT, LEDDZ_PIN)


void Leddz_Init();
void SB_Init();
void LEDDZ_ON();
void LEDDZ_OFF();


#endif
