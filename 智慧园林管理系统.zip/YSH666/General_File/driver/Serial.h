#ifndef __SERIAL_H
#define __SERIAL_H
#include "debug.h"

void uart4_init();
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);



#endif
