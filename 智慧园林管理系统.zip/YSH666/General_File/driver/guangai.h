#ifndef __GUANGAI_H
#define __GUANGAI_H
#include "debug.h"
void Guan_Init(void);
//u16 Guan_time(void);
u16 GET_Trsd_valu();
u16 GET_Trwd_valu();
void Guan_start();
//u16 Guan_time();
void Guan_time();

extern u16 gantime;

#endif
