#ifndef __DS18B20_H
#define __DS18B20_H

void DS18B20_IO_IN(void);
void DS18B20_IO_OUT(void);
void DS18B20_Reset(void);
u8 DS18B20_Check(void);
u8 DS18B20_Read_Bit(void);
u8 DS18B20_Read_Byte(void) ;
void DS18B20_Write_Byte(u8 dat);
void DS18B20_Start(void);
u8 DS18B20_Init(void);
float DS18B20_GetTemperture(void);



#endif














