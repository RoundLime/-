#ifndef __JDQ_H
#define __JDQ_H
void JD_ON_1(void);
void JD_OFF_1(void);
void JD_ON_2(void);
void JD_OFF_2(void);
#endif
