#include "debug.h"
#include "leddz.h"

void Leddz_Init(){

           RCC_APB2PeriphClockCmd(LEDDZ_CLK,ENABLE);
           GPIO_InitTypeDef GPIO_InitStructure;
           GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
           GPIO_InitStructure.GPIO_Pin = LEDDZ_PIN;
           GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
           GPIO_Init(LEDDZ_PORT, &GPIO_InitStructure);

}
void SB_Init()
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD ,ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_ResetBits(GPIOD, GPIO_Pin_5);

}
void LEDDZ_ON(){
    LEDDZ_RESET;
}

void LEDDZ_OFF(){
    LEDDZ_SET;
}
