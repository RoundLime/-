
#ifndef __CO2_H
#define __CO2_H
void co_Init();
u_int16_t get_co();
#endif


